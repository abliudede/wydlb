package com.lianzai.reader.event;

/**
 * Created by newbiechen on 17-5-10.
 * 下载进度事件
 */

public class DownloadMessage {

    public String message;

    public DownloadMessage(String message){
        this.message = message;
    }
}
