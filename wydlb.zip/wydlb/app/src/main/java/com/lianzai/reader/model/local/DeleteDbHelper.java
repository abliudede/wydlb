package com.lianzai.reader.model.local;


/**
 * Created by newbiechen on 17-4-28.
 */

public interface DeleteDbHelper {
    void deleteAll();
}
