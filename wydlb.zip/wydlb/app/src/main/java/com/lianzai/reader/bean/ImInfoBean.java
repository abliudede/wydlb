package com.lianzai.reader.bean;

public class ImInfoBean {
     private String yxAccid;
    private String yxToken;

    public String getYxAccid() {
        return yxAccid;
    }

    public void setYxAccid(String yxAccid) {
        this.yxAccid = yxAccid;
    }

    public String getYxToken() {
        return yxToken;
    }

    public void setYxToken(String yxToken) {
        this.yxToken = yxToken;
    }
}
