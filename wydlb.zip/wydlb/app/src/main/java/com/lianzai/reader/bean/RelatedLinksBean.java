package com.lianzai.reader.bean;

import java.util.List;

public class RelatedLinksBean {


    /**
     * code : 0
     * msg : success
     * data : {"author_name":"辰东","mySource":null,"sources":[{"source":"23us.so","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"https://www.23us.so/files/article/html/13/13694/19024626.html","updated_time":"2019-05-03 10:01:20"},{"chapter_title":"第1402章 踏帝行","chapter_url":"https://www.23us.so/files/article/html/13/13694/19137203.html","updated_time":"2019-05-09 14:31:20"},{"chapter_title":"第1403章 帝落时代","chapter_url":"https://www.23us.so/files/article/html/13/13694/19213719.html","updated_time":"2019-05-14 00:03:11"}]},{"source":"7dsw.com","chapters":[{"chapter_title":"第1397章 八卦炉中争雄","chapter_url":"https://www.7dsw.com/book/36/36409/64631572.html","updated_time":"2019-04-28 06:02:58"},{"chapter_title":"第1398章 一楚对五王","chapter_url":"https://www.7dsw.com/book/36/36409/64631573.html","updated_time":"2019-04-28 06:02:58"},{"chapter_title":"第1399章 石罐共鸣","chapter_url":"https://www.7dsw.com/book/36/36409/64631574.html","updated_time":"2019-04-28 06:02:58"}]},{"source":"aishula.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"http://www.aishula.com/html/1/1649/11713778.html","updated_time":"2019-05-03 12:01:18"},{"chapter_title":"第1402章 踏帝行","chapter_url":"http://www.aishula.com/html/1/1649/11733625.html","updated_time":"2019-05-09 14:31:18"},{"chapter_title":"第1403章 帝落时代","chapter_url":"http://www.aishula.com/html/1/1649/11742817.html","updated_time":"2019-05-14 00:03:08"}]},{"source":"beidouxin.com","chapters":[{"chapter_title":"第1395章 不朽地论生死","chapter_url":"http://www.beidouxin.com/read/4/4560/49031574.html","updated_time":"2019-04-15 12:06:56"},{"chapter_title":"第1396章 上苍的补偿","chapter_url":"http://www.beidouxin.com/read/4/4560/49160173.html","updated_time":"2019-04-15 21:19:21"},{"chapter_title":"第1397章 八卦炉中争雄","chapter_url":"http://www.beidouxin.comhttp://www.beidouxin.com/read/4/4560/49339783.html","updated_time":"2019-05-11 16:01:19"}]},{"source":"biquge.com.tw","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"http://www.biquyun.com/11_11850/9834600.html","updated_time":"2019-05-03 10:01:17"},{"chapter_title":"第1402章 踏帝行","chapter_url":"http://www.biquyun.com/11_11850/9842607.html","updated_time":"2019-05-09 14:31:21"},{"chapter_title":"第1403章 帝落时代","chapter_url":"http://www.biquyun.com/11_11850/9848510.html","updated_time":"2019-05-14 10:01:09"}]},{"source":"fpzw.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"https://www.fpzw.com/xiaoshuo/101/101999/27525180.html","updated_time":"2019-05-03 10:01:19"},{"chapter_title":"第1402章 踏帝行","chapter_url":"https://www.fpzw.com/xiaoshuo/101/101999/27551733.html","updated_time":"2019-05-09 14:31:19"},{"chapter_title":"第1403章 帝落时代","chapter_url":"https://www.fpzw.com/xiaoshuo/101/101999/27572583.html","updated_time":"2019-05-14 00:03:09"}]},{"source":"kuaiyankanshu.net","chapters":[{"chapter_title":"第1319章 是你回来了吗？","chapter_url":"https://www.kuaiyankanshu.net/1692/read_1320.html","updated_time":"2018-12-13 11:19:05"},{"chapter_title":"第1320章 问世间究竟有没有轮回","chapter_url":"https://www.kuaiyankanshu.net/1692/read_1321.html","updated_time":"2018-12-13 11:19:05"},{"chapter_title":"第1321章 天上掉下个天帝","chapter_url":"https://www.kuaiyankanshu.net/1692/read_1322.html","updated_time":"2018-12-17 11:29:45"}]},{"source":"kushubao.com","chapters":[{"chapter_title":"第1593章 又遇桃花劫","chapter_url":"http://www.kushubao.com/3608/28598860","updated_time":"2019-05-13 18:01:55"},{"chapter_title":"第1594章 农仕知道的秘密","chapter_url":"http://www.kushubao.com/3608/28598861","updated_time":"2019-05-13 18:01:55"},{"chapter_title":"第1595章 为了龙珠","chapter_url":"http://www.kushubao.com/3608/28598862","updated_time":"2019-05-13 18:01:55"}]},{"source":"lwxstxt.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"http://www.lwxstxt.com/1/1223/14260561.html","updated_time":"2019-05-03 10:01:17"},{"chapter_title":"第1402章 踏帝行","chapter_url":"http://www.lwxstxt.com/1/1223/14381988.html","updated_time":"2019-05-09 14:31:22"},{"chapter_title":"第1403章 帝落时代","chapter_url":"http://www.lwxstxt.com/1/1223/14457319.html","updated_time":"2019-05-14 10:01:09"}]},{"source":"meiguixs.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上传体","chapter_url":"https://www.meiguixs.com/html/10/10405/33290251.shtml","updated_time":"2019-05-14 00:03:09"},{"chapter_title":"第1402章 踏帝章行","chapter_url":"https://www.meiguixs.com/html/10/10405/33697586.shtml","updated_time":"2019-05-14 00:03:09"},{"chapter_title":"第1403章 帝落时 代","chapter_url":"https://www.meiguixs.com/html/10/10405/33977984.shtml","updated_time":"2019-05-14 00:03:09"}]},{"source":"mianhuatang520.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"https://www.mianhuatang2.com/xs/8322205/82606402.htm","updated_time":"2019-05-13 18:02:02"},{"chapter_title":"第1402章 踏帝行","chapter_url":"https://www.mianhuatang2.com/xs/8322205/82609534.htm","updated_time":"2019-05-13 18:02:02"},{"chapter_title":"第1403章 帝落时代","chapter_url":"https://www.mianhuatang2.com/xs/8322205/82611465.htm","updated_time":"2019-05-14 00:03:08"}]},{"source":"qidian.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"https://m.qidian.com/book/1004608738/463604160","updated_time":"2019-05-03 10:01:16"},{"chapter_title":"第1402章 踏帝行","chapter_url":"https://m.qidian.com/book/1004608738/464698816","updated_time":"2019-05-09 14:31:17"},{"chapter_title":"第1403章 帝落时代","chapter_url":"https://m.qidian.com/book/1004608738/465505410","updated_time":"2019-05-14 00:03:07"}]}],"book_name":"圣墟"}
     */

    private int code;
    private String msg;
    private DataBean data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * author_name : 辰东
         * mySource : null
         * sources : [{"source":"23us.so","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"https://www.23us.so/files/article/html/13/13694/19024626.html","updated_time":"2019-05-03 10:01:20"},{"chapter_title":"第1402章 踏帝行","chapter_url":"https://www.23us.so/files/article/html/13/13694/19137203.html","updated_time":"2019-05-09 14:31:20"},{"chapter_title":"第1403章 帝落时代","chapter_url":"https://www.23us.so/files/article/html/13/13694/19213719.html","updated_time":"2019-05-14 00:03:11"}]},{"source":"7dsw.com","chapters":[{"chapter_title":"第1397章 八卦炉中争雄","chapter_url":"https://www.7dsw.com/book/36/36409/64631572.html","updated_time":"2019-04-28 06:02:58"},{"chapter_title":"第1398章 一楚对五王","chapter_url":"https://www.7dsw.com/book/36/36409/64631573.html","updated_time":"2019-04-28 06:02:58"},{"chapter_title":"第1399章 石罐共鸣","chapter_url":"https://www.7dsw.com/book/36/36409/64631574.html","updated_time":"2019-04-28 06:02:58"}]},{"source":"aishula.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"http://www.aishula.com/html/1/1649/11713778.html","updated_time":"2019-05-03 12:01:18"},{"chapter_title":"第1402章 踏帝行","chapter_url":"http://www.aishula.com/html/1/1649/11733625.html","updated_time":"2019-05-09 14:31:18"},{"chapter_title":"第1403章 帝落时代","chapter_url":"http://www.aishula.com/html/1/1649/11742817.html","updated_time":"2019-05-14 00:03:08"}]},{"source":"beidouxin.com","chapters":[{"chapter_title":"第1395章 不朽地论生死","chapter_url":"http://www.beidouxin.com/read/4/4560/49031574.html","updated_time":"2019-04-15 12:06:56"},{"chapter_title":"第1396章 上苍的补偿","chapter_url":"http://www.beidouxin.com/read/4/4560/49160173.html","updated_time":"2019-04-15 21:19:21"},{"chapter_title":"第1397章 八卦炉中争雄","chapter_url":"http://www.beidouxin.comhttp://www.beidouxin.com/read/4/4560/49339783.html","updated_time":"2019-05-11 16:01:19"}]},{"source":"biquge.com.tw","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"http://www.biquyun.com/11_11850/9834600.html","updated_time":"2019-05-03 10:01:17"},{"chapter_title":"第1402章 踏帝行","chapter_url":"http://www.biquyun.com/11_11850/9842607.html","updated_time":"2019-05-09 14:31:21"},{"chapter_title":"第1403章 帝落时代","chapter_url":"http://www.biquyun.com/11_11850/9848510.html","updated_time":"2019-05-14 10:01:09"}]},{"source":"fpzw.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"https://www.fpzw.com/xiaoshuo/101/101999/27525180.html","updated_time":"2019-05-03 10:01:19"},{"chapter_title":"第1402章 踏帝行","chapter_url":"https://www.fpzw.com/xiaoshuo/101/101999/27551733.html","updated_time":"2019-05-09 14:31:19"},{"chapter_title":"第1403章 帝落时代","chapter_url":"https://www.fpzw.com/xiaoshuo/101/101999/27572583.html","updated_time":"2019-05-14 00:03:09"}]},{"source":"kuaiyankanshu.net","chapters":[{"chapter_title":"第1319章 是你回来了吗？","chapter_url":"https://www.kuaiyankanshu.net/1692/read_1320.html","updated_time":"2018-12-13 11:19:05"},{"chapter_title":"第1320章 问世间究竟有没有轮回","chapter_url":"https://www.kuaiyankanshu.net/1692/read_1321.html","updated_time":"2018-12-13 11:19:05"},{"chapter_title":"第1321章 天上掉下个天帝","chapter_url":"https://www.kuaiyankanshu.net/1692/read_1322.html","updated_time":"2018-12-17 11:29:45"}]},{"source":"kushubao.com","chapters":[{"chapter_title":"第1593章 又遇桃花劫","chapter_url":"http://www.kushubao.com/3608/28598860","updated_time":"2019-05-13 18:01:55"},{"chapter_title":"第1594章 农仕知道的秘密","chapter_url":"http://www.kushubao.com/3608/28598861","updated_time":"2019-05-13 18:01:55"},{"chapter_title":"第1595章 为了龙珠","chapter_url":"http://www.kushubao.com/3608/28598862","updated_time":"2019-05-13 18:01:55"}]},{"source":"lwxstxt.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"http://www.lwxstxt.com/1/1223/14260561.html","updated_time":"2019-05-03 10:01:17"},{"chapter_title":"第1402章 踏帝行","chapter_url":"http://www.lwxstxt.com/1/1223/14381988.html","updated_time":"2019-05-09 14:31:22"},{"chapter_title":"第1403章 帝落时代","chapter_url":"http://www.lwxstxt.com/1/1223/14457319.html","updated_time":"2019-05-14 10:01:09"}]},{"source":"meiguixs.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上传体","chapter_url":"https://www.meiguixs.com/html/10/10405/33290251.shtml","updated_time":"2019-05-14 00:03:09"},{"chapter_title":"第1402章 踏帝章行","chapter_url":"https://www.meiguixs.com/html/10/10405/33697586.shtml","updated_time":"2019-05-14 00:03:09"},{"chapter_title":"第1403章 帝落时 代","chapter_url":"https://www.meiguixs.com/html/10/10405/33977984.shtml","updated_time":"2019-05-14 00:03:09"}]},{"source":"mianhuatang520.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"https://www.mianhuatang2.com/xs/8322205/82606402.htm","updated_time":"2019-05-13 18:02:02"},{"chapter_title":"第1402章 踏帝行","chapter_url":"https://www.mianhuatang2.com/xs/8322205/82609534.htm","updated_time":"2019-05-13 18:02:02"},{"chapter_title":"第1403章 帝落时代","chapter_url":"https://www.mianhuatang2.com/xs/8322205/82611465.htm","updated_time":"2019-05-14 00:03:08"}]},{"source":"qidian.com","chapters":[{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"https://m.qidian.com/book/1004608738/463604160","updated_time":"2019-05-03 10:01:16"},{"chapter_title":"第1402章 踏帝行","chapter_url":"https://m.qidian.com/book/1004608738/464698816","updated_time":"2019-05-09 14:31:17"},{"chapter_title":"第1403章 帝落时代","chapter_url":"https://m.qidian.com/book/1004608738/465505410","updated_time":"2019-05-14 00:03:07"}]}]
         * book_name : 圣墟
         */

        private String author_name;
        private String mySource;
        private String book_name;
        private List<SourcesBean> sources;

        public String getAuthor_name() {
            return author_name;
        }

        public void setAuthor_name(String author_name) {
            this.author_name = author_name;
        }

        public String getMySource() {
            return mySource;
        }

        public void setMySource(String mySource) {
            this.mySource = mySource;
        }

        public String getBook_name() {
            return book_name;
        }

        public void setBook_name(String book_name) {
            this.book_name = book_name;
        }

        public List<SourcesBean> getSources() {
            return sources;
        }

        public void setSources(List<SourcesBean> sources) {
            this.sources = sources;
        }

        public static class SourcesBean {
            /**
             * source : 23us.so
             * chapters : [{"chapter_title":"第1401章 理论传说中的无上体","chapter_url":"https://www.23us.so/files/article/html/13/13694/19024626.html","updated_time":"2019-05-03 10:01:20"},{"chapter_title":"第1402章 踏帝行","chapter_url":"https://www.23us.so/files/article/html/13/13694/19137203.html","updated_time":"2019-05-09 14:31:20"},{"chapter_title":"第1403章 帝落时代","chapter_url":"https://www.23us.so/files/article/html/13/13694/19213719.html","updated_time":"2019-05-14 00:03:11"}]
             */

            private String source;
            private String sourceName;
            private boolean choose;
            private int randomInt;
            private List<ChaptersBean> chapters;
            private String first_chapter_url;
            private String catalog_url;

            public String getFirst_chapter_url() {
                return first_chapter_url;
            }

            public void setFirst_chapter_url(String first_chapter_url) {
                this.first_chapter_url = first_chapter_url;
            }

            public String getCatalog_url() {
                return catalog_url;
            }

            public void setCatalog_url(String catalog_url) {
                this.catalog_url = catalog_url;
            }

            public int getRandomInt() {
                return randomInt;
            }

            public void setRandomInt(int randomInt) {
                this.randomInt = randomInt;
            }

            public boolean isChoose() {
                return choose;
            }

            public void setChoose(boolean choose) {
                this.choose = choose;
            }

            public String getSourceName() {
                return sourceName;
            }

            public void setSourceName(String sourceName) {
                this.sourceName = sourceName;
            }

            public String getSource() {
                return source;
            }

            public void setSource(String source) {
                this.source = source;
            }

            public List<ChaptersBean> getChapters() {
                return chapters;
            }

            public void setChapters(List<ChaptersBean> chapters) {
                this.chapters = chapters;
            }

            public static class ChaptersBean {
                /**
                 * chapter_title : 第1401章 理论传说中的无上体
                 * chapter_url : https://www.23us.so/files/article/html/13/13694/19024626.html
                 * updated_time : 2019-05-03 10:01:20
                 */

                private String chapter_title;
                private String chapter_url;
                private String updated_time;

                public String getChapter_title() {
                    return chapter_title;
                }

                public void setChapter_title(String chapter_title) {
                    this.chapter_title = chapter_title;
                }

                public String getChapter_url() {
                    return chapter_url;
                }

                public void setChapter_url(String chapter_url) {
                    this.chapter_url = chapter_url;
                }

                public String getUpdated_time() {
                    return updated_time;
                }

                public void setUpdated_time(String updated_time) {
                    this.updated_time = updated_time;
                }
            }
        }
    }
}
