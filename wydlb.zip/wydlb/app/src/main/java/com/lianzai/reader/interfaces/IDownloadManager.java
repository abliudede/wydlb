package com.lianzai.reader.interfaces;

/**
 * Copyright (C), 2018
 * FileName: IDownloadManager
 * Author: lrz
 * Date: 2018/11/21 13:31
 * Description: ${DESCRIPTION}
 */
public interface IDownloadManager {
    void setOnDownloadListener(OnDownloadListener listener);
}
