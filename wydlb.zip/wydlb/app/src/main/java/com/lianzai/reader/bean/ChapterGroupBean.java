package com.lianzai.reader.bean;

/**
 * Copyright (C), 2018
 * FileName: ChapterGroupBean
 * Author: lrz
 * Date: 2018/11/7 11:32
 * Description: ${DESCRIPTION}
 */
public class ChapterGroupBean {

    public ChapterGroupBean(String title) {
        this.title = title;
    }

    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
