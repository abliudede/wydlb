package com.lianzai.reader.ui.activity.UrlIdentification.utils;

public interface WebViewJavaScriptFunction {

	void onJsFunctionCalled(String tag);
}
