package com.lianzai.reader.interfaces;

/**
 * Created by Vondear on 2017/9/22.
 */

public interface OnDelayListener {
    void doSomething();
}
