package com.lianzai.reader.bean;

public class PayForBookBean {


    /**
     * rewardImg : https://static.lianzai.com/static/book_reward/6.png
     * rewardAmt : 0.01000000
     * rewardContent : 666
     */

    private String rewardImg;
    private String rewardAmt;
    private String rewardContent;

    public String getRewardImg() {
        return rewardImg;
    }

    public void setRewardImg(String rewardImg) {
        this.rewardImg = rewardImg;
    }

    public String getRewardAmt() {
        return rewardAmt;
    }

    public void setRewardAmt(String rewardAmt) {
        this.rewardAmt = rewardAmt;
    }

    public String getRewardContent() {
        return rewardContent;
    }

    public void setRewardContent(String rewardContent) {
        this.rewardContent = rewardContent;
    }
}
