package com.lianzai.reader.model.local;


import com.lianzai.reader.model.bean.DownloadTaskBean;

/**
 * Created by newbiechen on 17-4-28.
 */

public interface SaveDbHelper {
    /*************DownloadTask*********************/
    void saveDownloadTask(DownloadTaskBean bean);
}
