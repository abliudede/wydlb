package com.lianzai.reader.bean;

import java.util.List;

public class ManagerAuditBean {


    /**
     * code : 0
     * msg : success
     * data : {"total":15,"list":[{"applyId":23,"userId":35869,"nickName":"哝哝君٩😛ི۶٩😛ི۶٩😛ི۶🦊🦊🦊","avatar":"https://static.lianzai.com/iOS_avatar/155384705554560.jpeg","gender":1,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":2179,"sendPostCount":16,"commentAndReplyCount":48,"applyType":3000,"applyContent":"1599","applyStatus":1},{"applyId":17,"userId":602924,"nickName":"用户id：602924","avatar":"https://static.lianzai.com/avatar/android_1554793427247.jpg","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":40,"sendPostCount":1,"commentAndReplyCount":3,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":16,"userId":602942,"nickName":"《哈哈哈》","avatar":"https://static.lianzai.com//avatar/head_pic_1556519825390.png","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":415,"sendPostCount":1,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":15,"userId":602944,"nickName":"连载书友804173","avatar":"https://static.lianzai.com/static/avatar.png","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":41,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":14,"userId":602946,"nickName":"蚂蚱","avatar":"https://static.lianzai.com/iOS_avatar/155894574851554.jpeg","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":null,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":13,"userId":603771,"nickName":"连载书友152404","avatar":"https://static.lianzai.com/static/avatar.png","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":null,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":12,"userId":602929,"nickName":"连载书友082939","avatar":"https://static.lianzai.com/static/avatar.png","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":null,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":19,"userId":26757,"nickName":"连载用户372358","avatar":"","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":null,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":20,"userId":602900,"nickName":"山有木兮木有枝-602900","avatar":"https://static.lianzai.com/avatar/android_1553666825680.jpg","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":103,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":11,"userId":603798,"nickName":"用户id: 603798","avatar":"https://static.lianzai.com/static/avatar.png","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":7200,"sendPostCount":2,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1}],"pageNum":1,"pageSize":10,"pages":2,"size":10}
     */

    private int code;
    private String msg;
    private DataBean data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * total : 15
         * list : [{"applyId":23,"userId":35869,"nickName":"哝哝君٩😛ི۶٩😛ི۶٩😛ི۶🦊🦊🦊","avatar":"https://static.lianzai.com/iOS_avatar/155384705554560.jpeg","gender":1,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":2179,"sendPostCount":16,"commentAndReplyCount":48,"applyType":3000,"applyContent":"1599","applyStatus":1},{"applyId":17,"userId":602924,"nickName":"用户id：602924","avatar":"https://static.lianzai.com/avatar/android_1554793427247.jpg","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":40,"sendPostCount":1,"commentAndReplyCount":3,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":16,"userId":602942,"nickName":"《哈哈哈》","avatar":"https://static.lianzai.com//avatar/head_pic_1556519825390.png","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":415,"sendPostCount":1,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":15,"userId":602944,"nickName":"连载书友804173","avatar":"https://static.lianzai.com/static/avatar.png","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":41,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":14,"userId":602946,"nickName":"蚂蚱","avatar":"https://static.lianzai.com/iOS_avatar/155894574851554.jpeg","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":null,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":13,"userId":603771,"nickName":"连载书友152404","avatar":"https://static.lianzai.com/static/avatar.png","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":null,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":12,"userId":602929,"nickName":"连载书友082939","avatar":"https://static.lianzai.com/static/avatar.png","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":null,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":19,"userId":26757,"nickName":"连载用户372358","avatar":"","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":null,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":20,"userId":602900,"nickName":"山有木兮木有枝-602900","avatar":"https://static.lianzai.com/avatar/android_1553666825680.jpg","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":103,"sendPostCount":0,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1},{"applyId":11,"userId":603798,"nickName":"用户id: 603798","avatar":"https://static.lianzai.com/static/avatar.png","gender":0,"circleId":459414,"circleName":"唐诗宋词","bookReadTime":7200,"sendPostCount":2,"commentAndReplyCount":0,"applyType":3000,"applyContent":"\n2019年的进度条，不知不觉已经过半。陪伴《时政新闻眼》一路走来的小伙伴们，你新年定下的小目标，是否已经有了眉目呢？这半年，在中国\u201c首席外交官\u201d习近平主席的引领下，中国外交成就斐然，屡创纪录，来看年中盘点。\n\n这个国家在西方大国中率先牵手\u201c一带一路\u201d\n\n\n\n","applyStatus":1}]
         * pageNum : 1
         * pageSize : 10
         * pages : 2
         * size : 10
         */

        private int total;
        private int pageNum;
        private int pageSize;
        private int pages;
        private int size;
        private List<ListBean> list;

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public int getPageNum() {
            return pageNum;
        }

        public void setPageNum(int pageNum) {
            this.pageNum = pageNum;
        }

        public int getPageSize() {
            return pageSize;
        }

        public void setPageSize(int pageSize) {
            this.pageSize = pageSize;
        }

        public int getPages() {
            return pages;
        }

        public void setPages(int pages) {
            this.pages = pages;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            /**
             * applyId : 23
             * userId : 35869
             * nickName : 哝哝君٩😛ི۶٩😛ི۶٩😛ི۶🦊🦊🦊
             * avatar : https://static.lianzai.com/iOS_avatar/155384705554560.jpeg
             * gender : 1
             * circleId : 459414
             * circleName : 唐诗宋词
             * bookReadTime : 2179
             * sendPostCount : 16
             * commentAndReplyCount : 48
             * applyType : 3000
             * applyContent : 1599
             * applyStatus : 1
             */

            private int applyId;
            private int userId;
            private String nickName;
            private String avatar;
            private int gender;
            private int circleId;
            private String circleName;
            private int bookReadTime;
            private int sendPostCount;
            private int commentAndReplyCount;
            private int applyType;
            private String applyContent;
            private int applyStatus;
            private String createTime;

            public String getCreateTime() {
                return createTime;
            }

            public void setCreateTime(String createTime) {
                this.createTime = createTime;
            }

            public int getApplyId() {
                return applyId;
            }

            public void setApplyId(int applyId) {
                this.applyId = applyId;
            }

            public int getUserId() {
                return userId;
            }

            public void setUserId(int userId) {
                this.userId = userId;
            }

            public String getNickName() {
                return nickName;
            }

            public void setNickName(String nickName) {
                this.nickName = nickName;
            }

            public String getAvatar() {
                return avatar;
            }

            public void setAvatar(String avatar) {
                this.avatar = avatar;
            }

            public int getGender() {
                return gender;
            }

            public void setGender(int gender) {
                this.gender = gender;
            }

            public int getCircleId() {
                return circleId;
            }

            public void setCircleId(int circleId) {
                this.circleId = circleId;
            }

            public String getCircleName() {
                return circleName;
            }

            public void setCircleName(String circleName) {
                this.circleName = circleName;
            }

            public int getBookReadTime() {
                return bookReadTime;
            }

            public void setBookReadTime(int bookReadTime) {
                this.bookReadTime = bookReadTime;
            }

            public int getSendPostCount() {
                return sendPostCount;
            }

            public void setSendPostCount(int sendPostCount) {
                this.sendPostCount = sendPostCount;
            }

            public int getCommentAndReplyCount() {
                return commentAndReplyCount;
            }

            public void setCommentAndReplyCount(int commentAndReplyCount) {
                this.commentAndReplyCount = commentAndReplyCount;
            }

            public int getApplyType() {
                return applyType;
            }

            public void setApplyType(int applyType) {
                this.applyType = applyType;
            }

            public String getApplyContent() {
                return applyContent;
            }

            public void setApplyContent(String applyContent) {
                this.applyContent = applyContent;
            }

            public int getApplyStatus() {
                return applyStatus;
            }

            public void setApplyStatus(int applyStatus) {
                this.applyStatus = applyStatus;
            }
        }
    }
}
