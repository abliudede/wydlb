package com.lianzai.reader.interfaces;

public interface OnTabChangedListner {
    void onTabSelected(int tabNum);
}
