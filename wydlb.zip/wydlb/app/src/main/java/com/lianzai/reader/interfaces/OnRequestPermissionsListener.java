package com.lianzai.reader.interfaces;

/**
 * Created by Administrator on 2017/3/10.
 */

public interface OnRequestPermissionsListener {
    void onRequestBefore();

    void onRequestLater();
}
