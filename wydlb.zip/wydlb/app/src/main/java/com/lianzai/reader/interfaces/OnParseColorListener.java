package com.lianzai.reader.interfaces;

/**
 * Created by lrz on 2018/1/3.
 */

public interface OnParseColorListener {
    void onFail();
}