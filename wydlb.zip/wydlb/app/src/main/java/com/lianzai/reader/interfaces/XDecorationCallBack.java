package com.lianzai.reader.interfaces;

/**
 * Created by lrz on 2017/12/9.
 */

public interface XDecorationCallBack {
    String getContent(int position);
}
