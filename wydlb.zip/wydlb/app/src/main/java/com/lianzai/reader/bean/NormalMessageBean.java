package com.lianzai.reader.bean;

public class NormalMessageBean {

    /**
     * content : 消息
     * img : 23
     * title : 撒旦法
     */

    private String content;
    private String img;
    private String title;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
