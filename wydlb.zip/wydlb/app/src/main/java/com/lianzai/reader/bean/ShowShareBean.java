package com.lianzai.reader.bean;

public class ShowShareBean {


    /**
     * code : “1021”
     * objId : “8835”
     * ext : https://static.lianzai.com/updatecover/7.jpg?W75XH100
     */

    private String code;
    private String objId;
    private String ext;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getObjId() {
        return objId;
    }

    public void setObjId(String objId) {
        this.objId = objId;
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext;
    }
}
