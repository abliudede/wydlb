package com.lianzai.reader.bean;

/**
 * Copyright (C), 2018
 * FileName: ImLianzaiHaoBean
 * Author: lrz
 * Date: 2018/9/12 11:20
 * Description: ${DESCRIPTION}
 */
public class ImLianzaiHaoBean {
    private String bookId;
    private String platformId;
    private String platformName;
    private String platformCover;
    private String penName;

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public String getPlatformName() {
        return platformName;
    }

    public void setPlatformName(String platformName) {
        this.platformName = platformName;
    }

    public String getPlatformCover() {
        return platformCover;
    }

    public void setPlatformCover(String platformCover) {
        this.platformCover = platformCover;
    }

    public String getPenName() {
        return penName;
    }

    public void setPenName(String penName) {
        this.penName = penName;
    }

}
